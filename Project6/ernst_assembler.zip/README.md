Alexandra Ernst

Time spent on project: 6 hours

To build:
- simply run `./Build.sh` from the main directory 
    - This builds the project using cmake
    - The executable `Assembler` should now be in the main directory
- To run the executable:
    - `./Assembler <input-file>`