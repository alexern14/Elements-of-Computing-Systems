mkdir build
cd build

cmake ..
make

cp ./Assembler ../
cd ..
